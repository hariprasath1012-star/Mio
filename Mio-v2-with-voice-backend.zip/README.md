# Mio — Tamil AI Song Maker

Mio is a free-first Android project for prompt-based Tamil AI song creation.

## Current build
- Prompt-based song UI
- Male/female/AI voice selection foundation
- Record user's own voice in-app
- Private/Public voice visibility UI
- Song styles
- My Songs and Public Voice Library sections
- Backend bridge for an open-source music-generation engine
- GitHub Actions APK build workflow

## AI engine
The backend is designed around ACE-Step 1.5, an open-source music-generation project with an HTTP API. Its documentation supports asynchronous generation and reference-audio upload. It can generate songs from prompts/lyrics and supports reference audio input. See the official project documentation:
https://github.com/ace-step/ACE-Step-1.5
https://github.com/ace-step/ACE-Step-1.5/blob/main/docs/en/API.md

## Cost reality
The Mio app can have no subscription/credit system, but AI generation still needs compute. Self-hosting the open-source engine avoids a per-song commercial API requirement, but a GPU/host may still have an electricity or cloud cost. This project does not claim unlimited AI generation is magically free.

## Voice privacy
Private voice: only the owner's account should be allowed to use it.
Public voice: only after explicit publishing consent; other users may select it.
The production backend must implement authentication, access control, deletion/revocation, abuse reporting, and secure storage before public release.

## Build
Push this project to GitHub and run the included "Build Mio APK" workflow.
