import os
import time
import httpx
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse

ACE_STEP_URL = os.getenv("ACE_STEP_URL", "http://127.0.0.1:8001")
ACE_STEP_KEY = os.getenv("ACE_STEP_KEY", "")

app = FastAPI(title="Mio Backend")

def headers():
    return {"Authorization": f"Bearer {ACE_STEP_KEY}"} if ACE_STEP_KEY else {}

@app.get("/health")
async def health():
    async with httpx.AsyncClient(timeout=10) as c:
        try:
            r = await c.get(f"{ACE_STEP_URL}/health")
            return {"mio": "ok", "ace_step": r.status_code == 200}
        except Exception:
            return {"mio": "ok", "ace_step": False}

@app.post("/generate")
async def generate(
    prompt: str = Form(...),
    lyrics: str = Form(""),
    voice_file: UploadFile | None = File(None),
):
    data = {"prompt": prompt, "lyrics": lyrics, "thinking": "true"}
    files = None
    if voice_file:
        content = await voice_file.read()
        files = {"reference_audio": (voice_file.filename or "voice.m4a", content, voice_file.content_type or "audio/mp4")}

    async with httpx.AsyncClient(timeout=120) as c:
        r = await c.post(
            f"{ACE_STEP_URL}/release_task",
            data=data,
            files=files,
            headers=headers(),
        )
    if r.status_code >= 400:
        raise HTTPException(r.status_code, r.text)
    return r.json()

@app.post("/result")
async def result(task_id: str = Form(...)):
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.post(
            f"{ACE_STEP_URL}/query_result",
            json={"task_ids": [task_id]},
            headers=headers(),
        )
    if r.status_code >= 400:
        raise HTTPException(r.status_code, r.text)
    return r.json()
