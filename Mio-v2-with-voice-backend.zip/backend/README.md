# Mio backend

This bridge connects the Mio Android app to a self-hosted ACE-Step 1.5 server.

## Important
The AI engine is open-source and can be self-hosted, but running it is not automatically free: a GPU/cloud machine may cost money. Mio itself does not require a paid subscription in this project.

ACE-Step exposes an async API:
- POST /release_task
- POST /query_result
- GET /v1/audio

Mio sends a prompt and optional user-provided voice reference to the backend.

Only accept voice samples that the uploader owns or has permission to use. Public voices should have explicit publishing consent and a revoke/delete mechanism.

## Run
1. Install Python 3.11+.
2. Install dependencies:
   pip install -r requirements.txt
3. Start your ACE-Step server separately.
4. Set:
   ACE_STEP_URL=http://127.0.0.1:8001
5. Run:
   uvicorn main:app --host 0.0.0.0 --port 8080
