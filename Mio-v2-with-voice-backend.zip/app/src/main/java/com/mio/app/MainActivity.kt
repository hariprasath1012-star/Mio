package com.mio.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.File

class MainActivity : ComponentActivity() {
    private var recorder: MediaRecorder? = null
    private var voiceFile: File? = null

    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MioApp(
                onStartRecording = {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    } else startRecording()
                },
                onStopRecording = { stopRecording() },
                recorded = voiceFile != null
            )
        }
    }

    private fun startRecording() {
        val file = File(cacheDir, "mio_voice_${System.currentTimeMillis()}.m4a")
        voiceFile = file
        recorder = MediaRecorder(this).apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(128000)
            setAudioSamplingRate(44100)
            setOutputFile(file.absolutePath)
            prepare()
            start()
        }
    }

    private fun stopRecording() {
        recorder?.runCatching { stop(); release() }
        recorder = null
    }

    override fun onDestroy() {
        recorder?.runCatching { stop(); release() }
        recorder = null
        super.onDestroy()
    }
}

@Composable
fun MioApp(
    onStartRecording: () -> Unit,
    onStopRecording: () -> Unit,
    recorded: Boolean
) {
    var prompt by remember { mutableStateOf("") }
    var voiceMode by remember { mutableStateOf("AI Voice") }
    var visibility by remember { mutableStateOf("Private") }
    var recording by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready to create") }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Mio 🎵") }) }
        ) { pad ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(pad).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("Tamil AI Song Maker", style = MaterialTheme.typography.headlineMedium)
                    Text("Describe your song and choose the voice you want to use.")
                }
                item {
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = { prompt = it },
                        modifier = Modifier.fillMaxWidth().height(150.dp),
                        label = { Text("Song prompt") },
                        placeholder = { Text("Sad Tamil love song, male voice, flute + piano, slow melody...") }
                    )
                }
                item {
                    Text("Voice", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("AI Voice", "My Voice").forEach {
                            FilterChip(
                                selected = voiceMode == it,
                                onClick = { voiceMode = it },
                                label = { Text(it) }
                            )
                        }
                    }
                }
                if (voiceMode == "My Voice") {
                    item {
                        Button(
                            onClick = {
                                if (!recording) {
                                    recording = true
                                    onStartRecording()
                                } else {
                                    recording = false
                                    onStopRecording()
                                    status = "Voice sample saved on this device"
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (recording) "⏹ Stop Recording" else "🎙️ Record My Voice")
                        }
                        if (recorded) Text("✓ Voice sample ready")
                    }
                    item {
                        Text("Voice visibility", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Private", "Public").forEach {
                                FilterChip(
                                    selected = visibility == it,
                                    onClick = { visibility = it },
                                    label = { Text(if (it == "Private") "🔒 Private" else "🌐 Public") }
                                )
                            }
                        }
                        Text(
                            if (visibility == "Private")
                                "Only your account can use this voice."
                            else
                                "Other users can use this voice after you publish it."
                        )
                    }
                }
                item {
                    Text("Style", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("Melody", "Kuthu", "Folk", "Sad", "Love").forEach {
                            TextButton(onClick = {}) { Text(it) }
                        }
                    }
                }
                item {
                    Button(
                        onClick = {
                            status = if (prompt.isBlank())
                                "Enter a prompt first"
                            else
                                "Ready — connect Mio backend to generate the song"
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) { Text("✨ Generate Song") }
                    Text(status)
                }
                item {
                    HorizontalDivider()
                    Text("My Songs", style = MaterialTheme.typography.titleLarge)
                    Text("Generated songs will appear here.")
                }
                item {
                    HorizontalDivider()
                    Text("Public Voice Library", style = MaterialTheme.typography.titleLarge)
                    Text("Published voices will appear here.")
                }
            }
        }
    }
}
